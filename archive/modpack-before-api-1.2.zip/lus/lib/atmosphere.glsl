vec3 lus_view_position(vec2 uv, float depth) {
    vec4 p = InvProjection * vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    if (abs(p.w) < 0.00001) return vec3(0.0, 0.0, -100000.0);
    return p.xyz / p.w;
}

float lus_hash(vec2 p) { return fract(sin(dot(p, vec2(71.43, 29.87))) * 21791.31); }
float lus_noise(vec2 p) {
    vec2 grid = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(lus_hash(grid), lus_hash(grid + vec2(1.0, 0.0)), f.x),
               mix(lus_hash(grid + vec2(0.0, 1.0)), lus_hash(grid + vec2(1.0)), f.x), f.y);
}
float lus_cloud_noise(vec2 p) {
    return lus_noise(p) * 0.57 + lus_noise(p * 2.1 + 13.7) * 0.28 + lus_noise(p * 4.3 - 7.1) * 0.15;
}

vec3 lus_air(vec3 color, vec3 p, float depth, float day, float outside) {
    // Atmosphere is zeroed by Raydiance in dimensions without a skylight.
    if (Atmosphere <= 0.0 || EyeInWater != 0) return color;
    vec3 ray = p / max(length(p), 0.0001);
    vec3 worldRay = (InvView * vec4(ray, 0.0)).xyz;
    float horizon = pow(clamp(1.0 - max(worldRay.y, 0.0), 0.0, 1.0), 3.0);
    float rain = clamp(max(Rain, Thunder * 0.7), 0.0, 1.0);
    vec3 sky = clamp(SkyColor, vec3(0.0), vec3(1.0));
    float dusk = (1.0 - smoothstep(0.12, 0.65, day)) * smoothstep(0.0, 0.12, day);
    float facing = clamp(dot(ray, Sun / max(length(Sun), 0.0001)), 0.0, 1.0);
    vec3 zenith = mix(vec3(0.018, 0.030, 0.075), mix(sky, vec3(0.20, 0.43, 0.76), 0.50), day);
    vec3 horizonColor = mix(vec3(0.065, 0.085, 0.15), vec3(0.72, 0.81, 0.87), day);
    horizonColor = mix(horizonColor, vec3(0.91, 0.52, 0.29), dusk * (0.25 + 0.65 * facing));
    vec3 hazeColor = mix(horizonColor, vec3(0.47, 0.51, 0.57) * (0.15 + 0.85 * day), rain * 0.8);
    if (depth < 0.999999) {
        float distance = length(p);
        float worldHeight = (InvView * vec4(p, 0.0)).y + CameraPosition.y;
        float lowland = 1.0 - smoothstep(64.0, 180.0, worldHeight);
        float density = (0.45 + lowland * 0.55 + rain * 1.2) / max(LUS_HAZE_REACH, 1.0);
        float amount = min(1.0 - exp(-max(distance - LUS_HAZE_START, 0.0) * density * Atmosphere), 0.75) * outside;
        return mix(color, hazeColor, amount);
    }
    vec3 skyGradient = mix(zenith, hazeColor, horizon);
    skyGradient = mix(skyGradient, hazeColor, rain * 0.35);
    // Preserve vanilla sun/moon/stars/cloud details above the sky background.
    vec3 features = max(color - sky, vec3(0.0));
    color = mix(color, skyGradient + features, clamp(Atmosphere * LUS_SKY, 0.0, 1.0));
    if (LUS_CLOUDS && worldRay.y > 0.025) {
        float travel = (LUS_CLOUD_HEIGHT - CameraPosition.y) / worldRay.y;
        if (travel > 0.0 && travel < 12000.0) {
            vec2 cloudPosition = (CameraPosition.xz + worldRay.xz * travel + vec2(Time * LUS_CLOUD_SPEED, 0.0)) / 100.0;
            float coverage = lus_cloud_noise(cloudPosition);
            float cloud = smoothstep(1.0 - LUS_CLOUD_COVER, 1.16 - LUS_CLOUD_COVER, coverage);
            cloud *= smoothstep(0.025, 0.14, worldRay.y) * (1.0 - smoothstep(0.0, 1.5, max(lus_luma(features), 0.0)));
            vec3 cloudColor = mix(vec3(0.12, 0.15, 0.22), vec3(0.96, 0.94, 0.87), day);
            color = mix(color, cloudColor, cloud * 0.75 * Atmosphere);
        }
    }
    return color + vec3(1.0, 0.72, 0.36) * pow(facing, 48.0) * Atmosphere * day * (1.0 - rain) * LUS_SUN_GLOW;
}

float lus_projected_shadow(vec3 position) {
    if (Shadows <= 0.0 || ShadowReady <= 0.5 || Daylight <= 0.02) return 1.0;
    vec4 clip = ShadowTransform * vec4(position, 1.0);
    if (abs(clip.w) < 0.00001) return 1.0;
    vec3 uv = clip.xyz / clip.w * 0.5 + 0.5;
    if (any(lessThan(uv, vec3(0.0))) || any(greaterThan(uv, vec3(1.0)))) return 1.0;
    vec2 pixel = 0.65 / vec2(textureSize(ShadowTex, 0));
    float z = uv.z - 0.0018;
    float light = step(z, texture(ShadowTex, uv.xy + vec2(-pixel.x, -pixel.y)).r);
    light += step(z, texture(ShadowTex, uv.xy + vec2(pixel.x, -pixel.y)).r);
    light += step(z, texture(ShadowTex, uv.xy + vec2(-pixel.x, pixel.y)).r);
    light += step(z, texture(ShadowTex, uv.xy + pixel).r);
    float border = min(min(uv.x, uv.y), min(1.0 - uv.x, 1.0 - uv.y));
    float fade = smoothstep(0.0, 0.10, border);
    return 1.0 - (1.0 - light * 0.25) * min(Shadows, 1.0) * fade * Daylight * (1.0 - Rain * 0.5) * 0.38;
}

float lus_contact_shadow(vec3 p, vec3 normal) {
    if (Shadows <= 0.0 || Daylight <= 0.02 || Rain >= 0.99) return 1.0;
    if (ShadowReady > 0.5) return lus_projected_shadow(p);
    // Short contact shadows use existing depth, including terrain imported by Direct.
    // Off-screen occluders are unavailable: this is not a world shadow map.
    float fade = 1.0 - smoothstep(20.0, 40.0, -p.z);
    if (fade <= 0.0) return 1.0;
    int count = clamp(min(Steps, LUS_CONTACT_STEPS), 1, 16);
    vec3 light = Sun / max(length(Sun), 0.0001);
    if (dot(normal, light) <= 0.04) return 1.0;
    for (int i = 1; i <= 16; i++) {
        if (i > count) break;
        float t = float(i) / float(count);
        vec3 ray = p + normal * 0.035 + light * (0.06 + t * t * LUS_CONTACT_REACH);
        vec4 clip = Projection * vec4(ray, 1.0);
        if (clip.w <= 0.0) break;
        vec2 uv = clip.xy / clip.w * 0.5 + 0.5;
        if (any(lessThan(uv, Texel)) || any(greaterThan(uv, vec2(1.0) - Texel))) break;
        float d = texture(Depth, uv).r;
        if (d >= 0.999999) continue;
        float gap = lus_view_position(uv, d).z - ray.z;
        if (gap > 0.025 && gap < 0.12 + abs(p.z) * 0.002) {
            return 1.0 - Shadows * 0.65 * (1.0 - t * 0.5) * fade * Daylight * (1.0 - Rain);
        }
    }
    return 1.0;
}

float lus_occlusion(vec3 p, vec3 normal) {
    if (Ssao <= 0.0 || -p.z > 64.0) return 1.0;
    int count = clamp(min(Steps, LUS_AO_SAMPLES), 1, 12);
    vec2 radius = vec2(Projection[0][0], Projection[1][1]) * 0.5 * 0.7 / max(-p.z, 0.2);
    float amount = 0.0;
    for (int i = 0; i < 12; i++) {
        if (i >= count) break;
        float a = float(i) * 2.39996;
        vec2 uv = texCoord + vec2(cos(a), sin(a)) * radius * sqrt((float(i) + 0.5) / float(count));
        if (any(lessThan(uv, Texel)) || any(greaterThan(uv, vec2(1.0) - Texel))) continue;
        float d = texture(Depth, uv).r;
        if (d >= 0.999999) continue;
        vec3 delta = lus_view_position(uv, d) - p;
        float distance = length(delta);
        amount += max(dot(normal, delta / max(distance, 0.0001)) - 0.12, 0.0)
                  * (1.0 - smoothstep(0.25, 1.4, distance)) * smoothstep(0.01, 0.05, distance);
    }
    return 1.0 - min(amount / float(count) * Ssao * 2.0, 0.45) * (1.0 - smoothstep(40.0, 64.0, -p.z));
}

vec3 lus_light(vec3 color, vec3 p, vec3 normal, float day, float outside, float continuity) {
    float contact = mix(1.0, lus_contact_shadow(p, normal), continuity);
    float ao = mix(1.0, lus_occlusion(p, normal), continuity);
    float direct = max(dot(normal, Sun / max(length(Sun), 0.0001)), 0.0);
    float amount = LUS_LIGHTING * outside * day * (1.0 - Rain * 0.8) * continuity;
    if (EyeInWater != 0) amount = 0.0;
    vec3 diffuse = mix(vec3(0.82, 0.89, 1.02), vec3(1.10, 1.04, 0.91), direct);
    return color * mix(vec3(1.0), diffuse, amount) * contact * ao;
}

vec3 lus_rays(float day) {
    if (GodRays <= 0.0 || day < 0.03 || Rain > 0.95 || EyeInWater != 0) return vec3(0.0);
    vec4 clip = Projection * vec4(Sun, 0.0);
    if (clip.w <= 0.001) return vec3(0.0);
    vec2 sunUv = clip.xy / clip.w * 0.5 + 0.5;
    float radial = 1.0 - smoothstep(0.10, 0.85, length(texCoord - sunUv));
    if (radial <= 0.0) return vec3(0.0);
    vec2 uv = texCoord; float visible = 0.0;
    for (int i = 0; i < 6; i++) {
        uv += (sunUv - texCoord) / 7.0;
        if (any(lessThan(uv, vec2(0.0))) || any(greaterThan(uv, vec2(1.0)))) break;
        visible += step(0.999999, texture(Depth, uv).r);
    }
    return vec3(1.0, 0.75, 0.45) * visible / 6.0 * radial * GodRays * day * (1.0 - Rain) * 0.18;
}
