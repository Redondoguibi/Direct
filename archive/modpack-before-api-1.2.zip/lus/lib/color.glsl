float lus_luma(vec3 c) {
    return dot(c, vec3(0.23, 0.67, 0.10));
}

vec3 lus_palette(vec3 source, float day, float outside) {
    vec3 c = max(source, vec3(0.0)) * (Brightness * exp2(Exposure));
    float lum = lus_luma(c);
    float highlight = smoothstep(0.14, 0.82, lum);
    vec3 shadeTint = mix(vec3(0.80, 0.91, 1.12), vec3(0.88, 0.96, 1.06), day);
    float dusk = (1.0 - smoothstep(0.12, 0.65, day)) * smoothstep(0.0, 0.12, day);
    vec3 lightTint = mix(vec3(0.91, 0.97, 1.09), vec3(1.08, 1.025, 0.91), day);
    lightTint = mix(lightTint, vec3(1.16, 1.035, 0.86), dusk * 0.65);
    // A camera underground must not make every nearby torch blue.
    float palette = LUS_PALETTE_AMOUNT * outside * (1.0 - 0.45 * clamp(Wetness, 0.0, 1.0));
    c *= mix(vec3(1.0), mix(shadeTint, lightTint, highlight), palette);
    // Lift only already-lit outdoor midtones. Black pixels and indoor darkness stay dark.
    c += vec3(lum * (1.0 - clamp(lum, 0.0, 1.0))) * LUS_NIGHT_LIFT * (1.0 - day) * outside;
    float chroma = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
    float saturation = Saturation + LUS_VIBRANCE * (1.0 - clamp(chroma * 2.0, 0.0, 1.0));
    c = mix(vec3(lus_luma(c)), c, saturation);
    // Smooth contrast keeps dark cave pixels distinguishable instead of clipping them.
    c = pow(max(c, vec3(0.0)), vec3(max(Contrast, 0.05))) * pow(0.45, 1.0 - max(Contrast, 0.05));
    c *= vec3(1.0 + Temperature * 0.12, 1.0, 1.0 - Temperature * 0.12);
    // Luminance-based shoulder keeps hue and does not lift all midtones.
    lum = lus_luma(c);
    float peak = max(lum - 0.55, 0.0);
    float mapped = min(lum, 0.55) + peak / (1.0 + peak * LUS_SHOULDER);
    vec3 shoulder = c * mapped / max(lum, 0.00001);
    c = mix(c, shoulder, clamp(ToneMapping, 0.0, 1.0));
    return pow(max(c, vec3(0.0)), vec3(1.0 / max(Gamma, 0.05)));
}
