// Lus / Raydiance 1.2.1+: configure tudo no F8 > Shaderpacks > Configurar shaderpack.
// Valores padrao e controles ficam no raydiance.json; escolhas pessoais ficam fora do pack.
uniform float PackLusPalette;
#define LUS_PALETTE_AMOUNT PackLusPalette
uniform float PackLusVibrance;
#define LUS_VIBRANCE PackLusVibrance
uniform float PackLusNightLift;
#define LUS_NIGHT_LIFT PackLusNightLift
uniform float PackLusShoulder;
#define LUS_SHOULDER PackLusShoulder
uniform float PackLusLighting;
#define LUS_LIGHTING PackLusLighting
uniform float PackLusSky;
#define LUS_SKY PackLusSky
uniform float PackLusSunGlow;
#define LUS_SUN_GLOW PackLusSunGlow
uniform float PackLusClouds;
#define LUS_CLOUDS (PackLusClouds > 0.5)
uniform float PackLusCloudCover;
#define LUS_CLOUD_COVER PackLusCloudCover
uniform float PackLusCloudHeight;
#define LUS_CLOUD_HEIGHT PackLusCloudHeight
uniform float PackLusCloudSpeed;
#define LUS_CLOUD_SPEED PackLusCloudSpeed
uniform float PackLusHazeStart;
#define LUS_HAZE_START PackLusHazeStart
uniform float PackLusHazeReach;
#define LUS_HAZE_REACH PackLusHazeReach
uniform float PackLusAoSamples;
#define LUS_AO_SAMPLES int(PackLusAoSamples)
uniform float PackLusContactSteps;
#define LUS_CONTACT_STEPS int(PackLusContactSteps)
uniform float PackLusContactReach;
#define LUS_CONTACT_REACH PackLusContactReach
