#version 150
// Lus: original world composite. One full-resolution pass plus optional engine bloom.
#include "lib/settings.glsl"

uniform sampler2D Scene, Depth, BloomTex, ShadowTex;
uniform vec2 Texel, ViewSize, EyeBrightness;
uniform float Saturation, Contrast, Brightness, Exposure, Gamma, Temperature, Vignette, Strength;
uniform float ToneMapping, Atmosphere, Bloom, Shadows, ShadowReady, Sharpen;
uniform float Daylight, Rain, Wetness, Thunder, Time, Ssao, GodRays;
uniform int Fxaa, EyeInWater, Steps;
uniform vec3 SkyColor, Sun, CameraPosition;
uniform mat4 Projection, InvProjection, InvView, ShadowTransform;
in vec2 texCoord;
out vec4 fragColor;

#include "lib/color.glsl"
#include "lib/atmosphere.glsl"

vec3 lus_spatial_filter(vec3 center) {
    if (Fxaa == 0 && Sharpen <= 0.0) return center;
    vec3 left = texture(Scene, texCoord - vec2(Texel.x, 0.0)).rgb;
    vec3 right = texture(Scene, texCoord + vec2(Texel.x, 0.0)).rgb;
    vec3 down = texture(Scene, texCoord - vec2(0.0, Texel.y)).rgb;
    vec3 up = texture(Scene, texCoord + vec2(0.0, Texel.y)).rgb;
    float centerLuma = lus_luma(center);
    float l = lus_luma(left), r = lus_luma(right), d = lus_luma(down), u = lus_luma(up);
    float low = min(centerLuma, min(min(l, r), min(d, u)));
    float high = max(centerLuma, max(max(l, r), max(d, u)));
    vec3 color = center;
    if (Fxaa != 0 && high - low > max(0.035, high * 0.13)) {
        float xEdge = abs(l + r - 2.0 * centerLuma);
        float yEdge = abs(d + u - 2.0 * centerLuma);
        vec3 alongEdge = xEdge > yEdge ? (down + up) * 0.5 : (left + right) * 0.5;
        color = mix(center, alongEdge, 0.30);
    }
    if (Sharpen > 0.0) {
        vec3 localLow = min(center, min(min(left, right), min(down, up)));
        vec3 localHigh = max(center, max(max(left, right), max(down, up)));
        vec3 detail = center - (left + right + down + up) * 0.25;
        color = clamp(color + detail * min(Sharpen, 1.0) * 0.25, localLow, localHigh);
    }
    return color;
}

void main() {
    vec4 original = texture(Scene, texCoord);
    if (Strength <= 0.0) { fragColor = original; return; }
    float depth = texture(Depth, texCoord).r;
    float day = clamp(Daylight, 0.0, 1.0);
    float outside = smoothstep(0.04, 0.65, EyeBrightness.y);
    vec3 position = lus_view_position(texCoord, depth);
    vec3 color = lus_spatial_filter(original.rgb);
    // Derivatives are evaluated for the whole quad before branching on geometry/sky.
    vec3 dx = dFdx(position), dy = dFdy(position);
    vec3 crossNormal = cross(dx, dy);
    vec3 normal = crossNormal / max(length(crossNormal), 0.00001);
    if (dot(normal, -position) < 0.0) normal = -normal;
    float continuity = 1.0 - smoothstep(0.05, 0.20, max(length(dx), length(dy)) / max(abs(position.z), 0.5));
    if (depth < 0.999999) color = lus_light(color, position, normal, day, outside, continuity);
    color = lus_air(color, position, depth, day, outside);
    color += lus_rays(day);
    if (Bloom > 0.0) color += min(texture(BloomTex, texCoord).rgb, vec3(1.0)) * min(Bloom, 1.0) * 0.8;
    color = lus_palette(color, day, outside);
    vec2 centered = (texCoord - 0.5) * vec2(min(ViewSize.x / max(ViewSize.y, 1.0), 2.0), 1.0);
    float vignette = smoothstep(0.12, 0.80, dot(centered, centered));
    color *= 1.0 - clamp(Vignette, 0.0, 1.0) * vignette;
    fragColor = vec4(mix(original.rgb, clamp(color, 0.0, 1.0), clamp(Strength, 0.0, 1.0)), original.a);
}
