// Lus 1.0.0 - optional, original Direct terrain detail pass.
// The full-scene palette runs once in Raydiance's OpenGL composite.
// Five color samples; no depth access, history buffers, LUTs or image assets.
Texture2D<float4> DirectInput : register(t0);
SamplerState DirectSampler : register(s0);
cbuffer LusFrame : register(b0) {
    float4 DirectFrameData;
    float4 DirectUniforms[15];
};
static const float LUS_DETAIL = 0.12;

float3 neighborOrCenter(float2 uv, float3 center) {
    float4 sampleColor = DirectInput.SampleLevel(DirectSampler, uv, 0.0);
    // Keep clear pixels from creating a dark outline around native terrain.
    return lerp(center, sampleColor.rgb, saturate(sampleColor.a));
}

float4 main(float4 position : SV_Position) : SV_Target0 {
    uint width, height;
    DirectInput.GetDimensions(width, height);
    float2 texel = 1.0 / float2(max(width, 1u), max(height, 1u));
    float2 uv = position.xy * texel;
    float4 original = DirectInput.SampleLevel(DirectSampler, uv, 0.0);
    if (original.a <= 0.0) return original;
    float3 left = neighborOrCenter(uv - float2(texel.x, 0.0), original.rgb);
    float3 right = neighborOrCenter(uv + float2(texel.x, 0.0), original.rgb);
    float3 down = neighborOrCenter(uv - float2(0.0, texel.y), original.rgb);
    float3 up = neighborOrCenter(uv + float2(0.0, texel.y), original.rgb);
    float3 low = min(original.rgb, min(min(left, right), min(down, up)));
    float3 high = max(original.rgb, max(max(left, right), max(down, up)));
    float3 detail = original.rgb - (left + right + down + up) * 0.25;
    float3 color = clamp(original.rgb + detail * LUS_DETAIL, low, high);
    return float4(saturate(color), original.a);
}
