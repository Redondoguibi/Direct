// raydiance:uniforms=1
// raydiance:depth=1
// Lus - Direct API 1.2: live detail and depth-aware edges.
// The full-scene palette runs once in Raydiance's OpenGL composite.
// Five color and depth samples; no history buffers, LUTs or image assets.
Texture2D<float4> DirectInput : register(t0);
Texture2D<float> DirectDepth : register(t1);
SamplerState DirectSampler : register(s0);
cbuffer LusFrame : register(b0) {
    float4 DirectFrameData;
    float4 DirectUniforms[15];
};

float3 neighborOrCenter(float2 uv, float3 center, float depth, uint2 dimensions) {
    float4 sampleColor = DirectInput.SampleLevel(DirectSampler, uv, 0.0);
    // Keep clear pixels from creating a dark outline around native terrain.
    int2 pixel=clamp(int2(uv*dimensions),int2(0,0),int2(dimensions)-1);
    float neighborDepth=DirectDepth.Load(int3(pixel,0));
    float sameSurface=abs(neighborDepth-depth)<0.025?1.0:0.0;
    return lerp(center, sampleColor.rgb, saturate(sampleColor.a)*sameSurface);
}

float4 main(float4 position : SV_Position) : SV_Target0 {
    uint width, height;
    DirectInput.GetDimensions(width, height);
    float2 texel = 1.0 / float2(max(width, 1u), max(height, 1u));
    float2 uv = position.xy * texel;
    float4 original = DirectInput.SampleLevel(DirectSampler, uv, 0.0);
    if (original.a <= 0.0) return original;
    float detailStrength=saturate(DirectUniforms[0].x);
    if(detailStrength<=0.0)return original;
    float depth=DirectDepth.Load(int3(int2(position.xy),0));
    uint2 dimensions=uint2(width,height);
    float3 left = neighborOrCenter(uv - float2(texel.x, 0.0), original.rgb,depth,dimensions);
    float3 right = neighborOrCenter(uv + float2(texel.x, 0.0), original.rgb,depth,dimensions);
    float3 down = neighborOrCenter(uv - float2(0.0, texel.y), original.rgb,depth,dimensions);
    float3 up = neighborOrCenter(uv + float2(0.0, texel.y), original.rgb,depth,dimensions);
    float3 low = min(original.rgb, min(min(left, right), min(down, up)));
    float3 high = max(original.rgb, max(max(left, right), max(down, up)));
    float3 detail = original.rgb - (left + right + down + up) * 0.25;
    float3 color = clamp(original.rgb + detail * detailStrength, low, high);
    return float4(saturate(color), original.a);
}
