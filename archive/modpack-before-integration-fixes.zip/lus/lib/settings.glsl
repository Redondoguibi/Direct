// LUS — ajustes extras. Recarregue o pack depois de editar este arquivo.
// Os controles normais (bloom, atmosfera, sombras, SSAO, cor, FXAA, etc.)
// ficam no F8 do Raydiance. Zero no controle desliga o respectivo efeito.
// Estes valores sao proprios do Lus; nenhum codigo ou asset do Mellow.
const float LUS_PALETTE_AMOUNT = 0.85; // 0..1: separacao de luz quente/sombra fria
const float LUS_VIBRANCE = 0.08;       // 0..0.3: reforco de cores pouco saturadas
const float LUS_NIGHT_LIFT = 0.06;    // 0..0.2: preserva detalhes da noite, nao clareia preto
const float LUS_SHOULDER = 0.65;      // 0..2: compressao suave de altas luzes
const float LUS_LIGHTING = 0.60;      // 0..1: modelagem direcional a partir da profundidade
const float LUS_SKY = 0.75;           // 0..1: gradiente do ceu, depende de Atmosfera no F8
const float LUS_HAZE_START = 20.0;    // blocos antes da nevoa adicional
const float LUS_HAZE_REACH = 200.0;   // alcance de extincao; maior = ar mais limpo
const float LUS_SUN_GLOW = 0.25;      // 0..1: halo solar, sem marcha volumetrica
const int LUS_AO_SAMPLES = 4;         // 4..12: custo do SSAO, tambem limitado por Qualidade
const int LUS_CONTACT_STEPS = 6;      // 4..16: sombras curtas em espaco de tela
const float LUS_CONTACT_REACH = 1.4;  // blocos; nao substitui um mapa de sombras de mundo
const bool LUS_CLOUDS = false;       // opcional: desligue nuvens vanilla antes de ativar
const float LUS_CLOUD_COVER = 0.48;   // 0..1
const float LUS_CLOUD_HEIGHT = 210.0; // altura do plano de nuvens, em blocos
const float LUS_CLOUD_SPEED = 0.8;   // blocos/segundo
